<!-- src/lib/components/Logo.svelte -->
<script lang="ts">
  // Recomputed from the raw path data: the original hand-off transform
  // (translate(0.572,-0.437) scale(0.03309) -> translate(0,512) scale(0.1,-0.1))
  // overshot the 16x16 viewBox by ~0.4-0.5 units on the top and bottom
  // edges. This single combined transform was solved directly against
  // the path data's true bounding box (x: 195-4298.6, y: 688-4460.3) to
  // center it in a 24x24 viewBox with an even 6% margin on all sides —
  // nothing clips, nothing is off-center.
  //
  // Colors use the site's own theme variables instead of the original
  // hardcoded #000000 / #0E00FF — that blue in particular fought the
  // Vintage Paper palette hard. --foreground and --primary both already
  // carry correct light/dark contrast (see app.css), so the mark
  // inherits it automatically with no extra logic here.
  export let size: number = 24;
  export let title: string = 'DixScript';
</script>

<svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="0 0 24 24"
  width={size}
  height={size}
  role="img"
  aria-label={title}
>
  <g transform="translate(0.436397,25.248239) scale(0.005147,-0.005147)">
    <path d="M565 2924 c-121 -69 -243 -139 -272 -156 -52 -29 -67 -47 -55 -65 13
-19 130 -93 169 -106 45 -15 1277 -671 1312 -699 13 -10 30 -18 38 -18 13 0
225 118 1223 683 146 82 272 156 280 163 13 12 12 16 -5 33 -25 25 -508 281
-529 281 -9 0 -18 -10 -21 -22 -5 -18 -106 -79 -447 -268 -242 -135 -453 -251
-467 -258 -27 -14 -43 -5 -510 272 -265 157 -485 286 -489 286 -4 0 -107 -57
-227 -126z" fill="var(--foreground)"/>
    <path d="M3598 2492 c-24 -3 -28 -8 -33 -50 -43 -334 -178 -654 -345 -822
-108 -108 -239 -173 -501 -248 -102 -29 -111 -30 -413 -37 l-309 -7 -113 -64
-114 -63 -297 164 c-206 115 -300 162 -311 156 -16 -9 -16 -122 -3 -605 l6
-228 230 1 c1216 5 1517 24 1795 113 111 36 181 70 267 130 281 197 622 609
724 872 39 100 78 251 85 331 20 201 24 338 11 351 -7 7 -624 12 -679 6z" fill="var(--foreground)"/>
    <path d="M1145 4450 c-7 -12 -7 -1064 1 -1082 5 -14 614 -362 651 -373 15 -4
28 0 42 14 20 20 21 31 21 379 l0 357 380 -3 c214 -2 387 1 396 6 22 12 195
-51 349 -128 210 -105 295 -193 410 -425 106 -212 162 -408 172 -600 l6 -100
344 0 c190 0 348 -2 353 -5 4 -3 10 -14 12 -25 9 -39 21 282 15 400 -9 174
-40 284 -136 480 -158 321 -429 682 -620 825 -160 121 -363 192 -706 250 -71
13 -134 26 -140 31 -13 13 -1542 12 -1550 -1z" fill="var(--primary)"/>
    <path d="M755 3623 c-115 -68 -235 -136 -265 -150 -54 -26 -140 -89 -140 -103
0 -28 123 -101 714 -424 457 -250 679 -366 699 -366 37 0 868 447 874 470 2 9
14 20 26 25 49 22 32 41 -109 119 -75 42 -142 76 -149 76 -6 0 -157 -83 -334
-184 l-323 -184 -77 42 c-43 22 -224 120 -404 216 l-327 175 57 51 58 52 -4
143 c-1 79 -8 150 -13 157 -25 29 -74 9 -283 -115z" fill="var(--primary)"/>
    <path d="M520 2355 c-314 -163 -325 -170 -325 -190 0 -15 157 -104 785 -442
432 -233 795 -423 806 -423 12 0 28 9 35 19 11 16 1122 653 1329 763 30 16 71
42 90 57 58 49 41 62 -198 164 -146 62 -213 86 -227 81 -11 -4 -227 -125 -480
-269 -253 -144 -487 -276 -520 -294 l-60 -33 -539 289 c-394 211 -541 295
-547 311 -5 12 -17 22 -26 22 -10 0 -66 -25 -123 -55z" fill="var(--primary)"/>
    <path d="M1690 1916 c0 -2 8 -10 18 -17 15 -13 16 -12 3 4 -13 16 -21 21 -21
13z" fill="var(--primary)"/>
    <path d="M2072 1333 c37 -2 100 -2 140 0 40 1 10 3 -67 3 -77 0 -110 -1 -73
-3z" fill="var(--primary)"/>
    <path d="M1154 885 c0 -104 2 -146 3 -92 2 54 2 139 0 190 -1 51 -3 7 -3 -98z" fill="var(--primary)"/>
    <path d="M2142 693 c82 -2 214 -2 295 0 82 1 15 3 -147 3 -162 0 -229 -2 -148
-3z" fill="var(--primary)"/>
  </g>
</svg>
