<!-- src/lib/components/docs/sections/DocGoApi.svelte -->
<script lang="ts">
  import CodeBlock from '$lib/components/CodeBlock.svelte';
  const install = `go get github.com/Mid-D-Man/dixscript-go

# Requirements:
#   Go 1.21+
#   CGO_ENABLED=1        (default for native builds — does NOT work with CGO_ENABLED=0)
#   a C compiler (gcc/clang), needed by cgo
#
# One-time setup after cloning DixScript-Rust:
#   cargo build -p mdix-ffi --release
#   mkdir -p mdix-go/internal/lib/linux-amd64
#   cp target/release/libmdix_ffi.so mdix-go/internal/lib/linux-amd64/
#   # (darwin-arm64 / windows-amd64 equivalents also exist under internal/lib/)`;

  const quickStart = `import dixscript "github.com/Mid-D-Man/dixscript-go"

db, err := dixscript.Load("config.mdix")
if err != nil {
    log.Fatal(err)
}
defer db.Close()

port, _  := db.GetInt("server.port")
host, _  := db.GetString("server.host")
debug, _ := db.GetBool("debug")`;

  const loadApi = `db, err := dixscript.Load("config.mdix")           // from file
db, err := dixscript.LoadStr(src)                   // from string
db, err := dixscript.LoadEncrypted(enc, key)        // encrypted + key file
db, err := dixscript.LoadEncryptedPassword(enc, pw) // encrypted + password
db, err := dixscript.LoadJSON(jsonStr)              // from JSON
db, err := dixscript.LoadToml(tomlStr)              // from TOML
defer db.Close()`;

  const readApi = `s, err   := db.GetString("path")
i, err   := db.GetInt("path")
f32, err := db.GetFloat32("path")
f64, err := db.GetFloat64("path")
b, err   := db.GetBool("path")

// Special types
color, err := db.GetHexColor("primary_color")   // -> HexColor{R,G,B,A float32}
blob,  err := db.GetBlob("icon_data")            // -> Blob; call .Bytes()
re,    err := db.GetRegex("validation_pattern")  // -> MdixRegex; call .Compile()
date,  err := db.GetDate("release_date")         // -> MdixDate{Value time.Time}
ts,    err := db.GetTimestamp("created_at")      // -> MdixTimestamp{Value time.Time}

// Enums
name,  err := db.GetEnumName("ai_type")   // -> "AIType"
field, err := db.GetEnumField("ai_type")  // -> "BOSS"
val,   err := db.GetEnumValue("ai_type")  // -> 2 (resolved int)

// Introspection
typ      := db.ValueTypeAt("path")   // -> dixscript.TypeInt, TypeString, ...
ok       := db.Exists("path")        // -> bool
n, err   := db.ArrayLength("path")
keys, err := db.Keys("")             // top-level keys ("" = no prefix filter)`;

  const errorApi = `port, err := db.GetInt("server.port")
if err != nil {
    var me *dixscript.MdixError
    if errors.As(err, &me) {
        switch me.Kind {
        case dixscript.ErrNotFound:
            // path doesn't exist
        case dixscript.ErrTypeMismatch:
            // wrong type at path
        case dixscript.ErrClosed:
            // database was already closed
        }
    }
}`;

  const builderApi = `b := dixscript.NewBuilder()
defer b.Close()

b.SetString("profile.name", "player1")
b.SetInt("profile.level", 42)
b.SetFloat64("profile.score", 9876.5)
b.SetBool("profile.active", true)
b.SetDate("profile.joined", time.Now())

err := b.SaveToFile("profile.mdix")

// Or get it as a string
src, err := b.ToString()

// Or load it directly
db, err := b.ToDatabase()
defer db.Close()`;

  const converterApi = `// Export
json, err := dixscript.Convert.ToJSON(db, true)
mdix, err := dixscript.Convert.ToMdix(db, dixscript.FormatPretty)
toml, err := dixscript.Convert.ToToml(db)

// Import
db, err := dixscript.Convert.FromJSON(jsonStr)
db, err := dixscript.Convert.FromToml(tomlStr)

// Format source text
formatted, err := dixscript.Convert.FormatSource(src, dixscript.FormatCompact)
minified,  err := dixscript.Convert.MinifySource(src)`;

  const queryApi = `type Enemy struct {
    Name string \`json:"name"\`
    HP   int    \`json:"hp"\`
}

// LoadQuery reads a group array at path straight into a *Query[T]
enemies, err := dixscript.LoadQuery[Enemy](db, "enemies")

// Or wrap a slice you already have
q := dixscript.NewQuery(myEnemies)

// Chainable, lazy until a terminal call
boss, ok := enemies.
    Where(func(e Enemy) bool { return e.HP > 100 }).
    OrderByDesc(func(e Enemy) int { return e.HP })).
    First()

names := dixscript.Select(enemies, func(e Enemy) string { return e.Name })
total := dixscript.SumInt(enemies, func(e Enemy) int64 { return int64(e.HP) })
avg, ok := dixscript.AvgFloat(enemies, func(e Enemy) float64 { return float64(e.HP) })
groups := dixscript.GroupBy(enemies, func(e Enemy) string { return e.Name[:1] })

// Or skip Query[T] entirely for a one-shot decode
var raw []Enemy
jsonStr, err := db.QueryManyJSON("enemies.*")
json.Unmarshal([]byte(jsonStr), &raw)`;

  const schemaApi = `schema := dixscript.NewSchema().
    RequireString("app_name").
    RequireInt("server.port").
    RequireBool("ssl").
    OptionalString("description").
    OptionalInt("timeout")

report := schema.Validate(db)

if !report.IsValid() {
    for _, e := range report.Errors {
        fmt.Println(e.Error()) // path, expected type, actual type
    }
    fmt.Println(report.FailedPaths())
}

// Require(path, type) / Optional(path, type) accept a dixscript.ValueType
// directly for anything beyond the typed RequireString/RequireInt/...
// shorthands above.`;

  const mergeApi = `// Two or more .mdix source strings — sources[0] has the highest
// implicit weight, sources[len-1] the lowest.
merged, conflicts, err := dixscript.MergeSources(
    []string{baseSrc, overlaySrc},
    dixscript.PrimaryWins,   // or WeightedPriority / SecondaryWins / ThrowOnConflict
    dixscript.ArrayConcatDedup, // or ArrayConcat / ArrayReplace
)
defer merged.Close()

for _, c := range conflicts {
    fmt.Printf("%s: source %d (%s) won\\n", c.Path, c.WinningSource, c.WinningLabel)
}

// Explicit weights instead of positional priority
merged, conflicts, err := dixscript.MergeSourcesWeighted(
    []string{baseSrc, overlaySrc},
    []float64{1.0, 0.5},
    dixscript.WeightedPriority,
    dixscript.ArrayConcatDedup,
)`;

  const watchApi = `db, err := dixscript.Load("config.mdix")
defer db.Close()

db.OnReloaded(func(reloaded *dixscript.Database) {
    log.Println("config reloaded")
})
db.OnReloadFailed(func(err error) {
    log.Printf("reload failed: %v", err)
})

err = db.EnableHotReload(2 * time.Second) // poll interval
defer db.DisableHotReload()

db.IsHotReloadEnabled() // -> bool

// Note: EnableHotReload polls the source path Load() originally used —
// it has nothing to reload from for LoadStr()-created databases.`;

  const layout = `mdix-go/
├── dixscript.go           # Load*, NewBuilder, Version — top-level facade
├── database.go            # Database type — all typed getters
├── builder.go             # Builder type — Set*, Save, ToString
├── converter.go           # Convert.ToJSON / FromJSON / ToToml / Format / Minify
├── query.go               # Query[T] — generic LINQ-style helpers
├── schema.go              # SchemaBuilder — Require*/Optional* validation
├── merge.go               # MergeSources / MergeSourcesWeighted
├── watch.go               # EnableHotReload / OnReloaded / OnReloadFailed
├── types.go               # HexColor, Blob, MdixRegex, MdixDate, MdixTimestamp, ValueType
├── errors.go              # MdixError, ErrorKind constants
├── internal/
│   ├── ffi.go             # all cgo declarations — the only file with unsafe
│   ├── include/mdix_ffi.h # generated by cbindgen — do not edit
│   └── lib/                # native libs — populated by CI or local cargo build
└── examples/
    ├── basic/main.go
    └── game_config/main.go`;
</script>

<div class="doc-page">
  <h1>Go Runtime API</h1>
  <p class="page-lead">
    <code>github.com/Mid-D-Man/dixscript-go</code> wraps the Rust core via
    cgo, exposing idiomatic Go <code>(value, error)</code> returns
    throughout — no exceptions, no Result wrapper type, just standard Go
    error handling.
  </p>

  <h2>Install</h2>
  <CodeBlock code={install} lang="bash" />

  <h2>Quick Start</h2>
  <CodeBlock code={quickStart} lang="go" />

  <h2>Loading</h2>
  <CodeBlock code={loadApi} lang="go" />

  <h2>Reading Values</h2>
  <CodeBlock code={readApi} lang="go" />

  <h2>Error Handling</h2>
  <p>
    Every function returns an idiomatic <code>(value, error)</code> pair.
    The error type is <code>*MdixError</code> — use <code>errors.As</code>
    to inspect its <code>Kind</code>.
  </p>
  <CodeBlock code={errorApi} lang="go" />

  <div class="table-scroll">
    <table>
      <thead><tr><th>Error Kind</th><th>Meaning</th></tr></thead>
      <tbody>
        {#each [
          { k: 'dixscript.ErrNotFound',     d: 'The requested path does not exist.' },
          { k: 'dixscript.ErrTypeMismatch', d: 'The value at the path cannot be converted to the requested type.' },
          { k: 'dixscript.ErrClosed',       d: 'The database/builder handle was already closed.' },
        ] as row}
          <tr>
            <td><code style="font-size:0.75rem">{row.k}</code></td>
            <td style="color:var(--muted-foreground);font-size:0.8125rem">{row.d}</td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>

  <h2>Building Programmatically</h2>
  <CodeBlock code={builderApi} lang="go" />

  <h2>Format Conversion</h2>
  <CodeBlock code={converterApi} lang="go" />

  <h2>Query — LINQ-style Helpers</h2>
  <p>
    <code>Query[T]</code> and its generic free functions (<code>Select</code>,
    <code>OrderBy</code>, <code>GroupBy</code>, <code>SumInt</code>,
    <code>AvgFloat</code>, ...) give you filtering/projection/aggregation
    over a group array without hand-decoding JSON.
  </p>
  <CodeBlock code={queryApi} lang="go" />

  <h2>Schema Validation</h2>
  <p>
    <code>SchemaBuilder</code> — fluent, declarative required/optional
    field validation against a loaded <code>*Database</code>.
  </p>
  <CodeBlock code={schemaApi} lang="go" />

  <h2>Merging Databases</h2>
  <p>
    AST-level merge — no JSON round-trip, so every DixScript type survives
    exactly. Conflicts are reported per key, never silently resolved
    without you knowing.
  </p>
  <CodeBlock code={mergeApi} lang="go" />

  <h2>Hot Reload</h2>
  <CodeBlock code={watchApi} lang="go" />

  <h2>Package Layout</h2>
  <CodeBlock code={layout} lang="text" />

  <h2>vs C#</h2>
  <div class="table-scroll">
    <table>
      <thead><tr><th>Concept</th><th>C#</th><th>Go</th></tr></thead>
      <tbody>
        {#each [
          { c: 'Load',    cs: 'Dix.Load(path)',                  go: 'dixscript.Load(path)' },
          { c: 'Read',    cs: 'db.GetInt("path").OrThrow()',     go: 'db.GetInt("path") -> (int, error)' },
          { c: 'Build',   cs: 'MdixBuilder.Create()',            go: 'dixscript.NewBuilder()' },
          { c: 'Close',   cs: 'using var db = ... (IDisposable)', go: 'defer db.Close() (io.Closer)' },
          { c: 'Errors',  cs: 'MdixResult<T> with .IsSuccess',   go: '(T, error) idiomatic Go' },
          { c: 'FFI glue',cs: 'csbindgen auto-generates MdixNative.cs', go: 'cgo, hand-written internal/ffi.go' },
          { c: 'Header',  cs: 'not needed',                       go: 'mdix_ffi.h (cbindgen generated)' },
        ] as row}
          <tr>
            <td style="font-weight:500">{row.c}</td>
            <td><code style="font-size:0.75rem">{row.cs}</code></td>
            <td><code style="font-size:0.75rem">{row.go}</code></td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>
</div>
