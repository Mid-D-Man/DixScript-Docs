<script lang="ts">
  import HeroSection      from '$lib/components/HeroSection.svelte';
  import InstallStrip     from '$lib/components/InstallStrip.svelte';
  import SyntaxComparison from '$lib/components/SyntaxComparison.svelte';
  import GameComparison   from '$lib/components/GameComparison.svelte';
  import FeaturesSection  from '$lib/components/FeaturesSection.svelte';
</script>

<svelte:head>
  <title>DixScript — The Swiss Army Knife of Data Formats</title>
  <meta
    name="description"
    content="DixScript: A programmable configuration format with intelligent deduplication. 68%+ compression, 5 DLM modules, compile-time functions, built-in encryption. Zero dependencies."
  />
</svelte:head>

<HeroSection />
<InstallStrip />
<SyntaxComparison />
<GameComparison />
<FeaturesSection />
