<!-- src/lib/components/docs/sections/DocTypes.svelte -->
<script lang="ts">
  import CodeBlock from '$lib/components/CodeBlock.svelte';
  const types = [
    { type: 'int',       example: '42, -17, 0',                    desc: 'Signed 32-bit integer',                    ideal: 'Counts, ports, IDs, version numbers' },
    { type: 'long',       example: '9_000_000_000L, 0xDEAD_BEEFL',   desc: 'Signed 64-bit integer — L/l suffix, or auto-promoted when a plain integer overflows i32', ideal: 'Timestamps in ms, large IDs (Discord/Snowflake-style), file sizes, counters that can exceed 2^31' },
    { type: 'float',     example: '3.14f, -2.5f, 42f',             desc: 'Single-precision — f suffix required',      ideal: 'Game physics, weights, factors where f suffix makes intent clear' },
    { type: 'double',    example: '3.14159, 2.718e10',              desc: 'Double-precision float',                   ideal: 'Scientific values, monetary ratios, coordinates' },
    { type: 'string',    example: '"hi", \'hi\', `hi`',              desc: 'Double, single, or backtick quoted',        ideal: 'Names, URLs, messages, paths, labels' },
    { type: 'bool',      example: 'true, false',                    desc: 'Boolean',                                  ideal: 'Feature flags, enabled/disabled switches, SSL' },
    { type: 'hex',       example: '0xFF, 0xDEAD_BEEF',              desc: 'Hex integer literal (int, or long with L suffix / overflow)', ideal: 'Bitmasks, memory addresses, raw byte values' },
    { type: 'binary',    example: '0b1010_1100, 0b1111L',           desc: 'Binary integer literal — 0b/0B prefix (int, or long with L suffix / overflow)', ideal: 'Flag bytes, protocol bitfields, permission masks' },
    { type: 'hex color', example: '#FF5733, #F00, #FF5733CC',       desc: 'RGB or RGBA hex colour',                   ideal: 'Theme colours, UI palette, brand values' },
    { type: 'date',      example: '2025-01-15',                     desc: 'ISO 8601 date (no time component)',         ideal: 'Expiry dates, release dates, start/end dates' },
    { type: 'timestamp', example: '2025-01-15T10:30:00Z',           desc: 'ISO 8601 timestamp with optional TZ',      ideal: 'Created-at, updated-at, exact event times' },
    { type: 'blob',      example: 'b:("SGVsbG8=")',                 desc: 'Base64-encoded binary data',               ideal: 'Embedded certificates, icons, encrypted payloads, checksums' },
    { type: 'regex',     example: 'r:("^[a-z]+$")',                 desc: 'Regular expression pattern',               ideal: 'Validation rules, input patterns, routing patterns' },
    { type: 'tuple',     example: 't:(1, "text", true)',             desc: 'Mixed-type, up to 6 elements',             ideal: 'Bundling 2–6 related values without a named object' },
    { type: 'array',     example: '[1, 2, 3]',                      desc: 'Homogeneous array literal',                ideal: 'Lists of IDs, tags, allowed values, ordered sequences' },
    { type: 'object',    example: '{ id = 1, name = "x" }',         desc: 'Inline object literal',                    ideal: 'Structured sub-values, config blocks, return values from QuickFuncs' },
    { type: 'enum',      example: 'Status.ACTIVE',                  desc: 'Enum value reference — compile-time only', ideal: 'Discrete states, log levels, environments, rarities' },
    { type: 'null',      example: 'null',                           desc: 'Explicit null / absence of value',         ideal: 'Optional fields, unset markers, conditional presence' },
  ];

  const cmpRows = [
    { feature: 'Compile-time functions', json: false, yaml: false, toml: false, jsonnet: true,  cue: true,  hcl: true,  dix: true },
    { feature: 'Built-in encryption',    json: false, yaml: false, toml: false, jsonnet: false, cue: false, hcl: false, dix: true },
    { feature: 'Built-in compression',   json: false, yaml: false, toml: false, jsonnet: false, cue: false, hcl: false, dix: true },
    { feature: 'Enums / constants',      json: false, yaml: false, toml: false, jsonnet: true,  cue: true,  hcl: false, dix: true },
    { feature: 'Comments',               json: false, yaml: true,  toml: true,  jsonnet: true,  cue: true,  hcl: true,  dix: true },
    { feature: 'Optional trailing comma',json: false, yaml: true,  toml: false, jsonnet: true,  cue: true,  hcl: true,  dix: true },
    { feature: 'Zero runtime deps',      json: true,  yaml: false, toml: true,  jsonnet: false, cue: false, hcl: false, dix: true },
    { feature: 'Import system',          json: false, yaml: false, toml: false, jsonnet: true,  cue: true,  hcl: true,  dix: true },
    { feature: 'Blob / binary type',     json: false, yaml: false, toml: false, jsonnet: false, cue: false, hcl: false, dix: true },
    { feature: 'Regex type',             json: false, yaml: false, toml: false, jsonnet: false, cue: true,  hcl: false, dix: true },
    { feature: 'Tuple type',             json: false, yaml: false, toml: false, jsonnet: false, cue: false, hcl: true,  dix: true },
    { feature: 'Date / Timestamp type',  json: false, yaml: true,  toml: true,  jsonnet: false, cue: true,  hcl: false, dix: true },
    { feature: '64-bit integer type',    json: false, yaml: true,  toml: true,  jsonnet: false, cue: true,  hcl: false, dix: true },
    { feature: 'Type validation',        json: false, yaml: false, toml: false, jsonnet: false, cue: true,  hcl: false, dix: true },
    { feature: 'Schema enforcement',     json: false, yaml: false, toml: false, jsonnet: false, cue: true,  hcl: false, dix: true },
  ];

  const usageExample = `@DATA(
  // Practical examples of each type
  port<int>          = 8080
  session_id<long>   = 9_000_000_000L       // explicit L suffix
  file_size<long>    = 3_000_000_000        // auto-promoted — overflows i32
  ratio<float>       = 0.75f
  pi<double>         = 3.14159265358979
  name<string>       = "MyService"
  enabled<bool>      = true
  mask<hex>          = 0xFF_FF              // underscores allowed as a separator
  flags<hex>         = 0b0000_1111          // binary literal, same <hex> annotation
  wide_flags<long>   = 0b1111_0000_1111L    // binary + L suffix -> Long
  brand<hex>         = #2D6A9F
  launch<date>       = 2025-06-01
  built<timestamp>   = 2025-01-15T08:00:00Z
  cert<blob>         = b:("LS0tLS1CRUdJTi==")
  email<regex>       = r:("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$")
  origin<tuple>      = t:(0, 0, "centre")
  allowed_ids<array> = [1, 2, 3, 4, 5]
  server<object>     = { host = "localhost", port = 8080 }
  env<enum>          = Environment.PROD
  optional           = null
)`;

  const numericRulesExample = `// UNDERSCORE SEPARATORS — any integer, hex, or binary literal may
// contain '_' between digits as a visual separator. Stripped before parsing.
big     = 1_000_000        // Integer(1000000)
mask    = 0xFF_FF          // Integer(65535)
flags   = 0b1111_0000      // Integer(240)
// NOTE: underscores are NOT supported inside date/timestamp literals.

// LONG (64-BIT) — append L or l to any integer literal (decimal, hex, or
// binary). Valid combos: decimal+L, hex+L, binary+L.
users   = 9_000_000_000L     // Long(9000000000)
addr    = 0xDEAD_BEEFL       // Long(3735928559)
wide    = 0b1111_0000_1111L  // Long(3855)

// AUTO-PROMOTION — a plain integer with no suffix that overflows i32 is
// silently emitted as Long. No 'L' needed:
huge    = 3_000_000_000      // Long(3000000000)
big_hex = 0xFF_FF_FF_FF      // Long(4294967295) — overflows i32

// FLOAT vs DOUBLE — 'f'/'F' suffix -> f32 (Float). No suffix + decimal
// point -> f64 (Double). 'L' and 'f'/'F' are mutually exclusive; putting
// 'L' on a float literal is a lex error.
rate    = 3.14f              // Float (f32)
pi      = 3.14159265358979   // Double (f64)`;

  const interpolatedExample = `@QUICKFUNCS(
  ~endpoint<string>(host<string>, port<int>) {
    return $"https://{host}:{port.toString()}/api"
  }
)`;

  const stringStylesExample = `@DATA(
  // "..." and '...' — identical semantics, escape-processed the usual way
  double_quoted = "She said \\"hi\\""
  single_quoted = 'She said "hi"'

  // \`...\` — raw / verbatim. No escape processing at all, so embedded " and '
  // need no escaping, and the content may span literal newlines. Ideal for
  // apostrophe-heavy or multilingual text, and any string with mixed quotes.
  raw_quote     = \`She said "hi" — that's the whole sentence, unescaped\`
  raw_multiline = \`line one
line two\`
)`;
</script>

<div class="doc-page">
  <h1>Data Types</h1>
  <p class="page-lead">
    Types are inferred from the assigned value. Add explicit annotations
    (<code>&lt;int&gt;</code>, <code>&lt;long&gt;</code>, <code>&lt;float&gt;</code>, <code>&lt;enum&gt;</code> etc.)
    where you want the compiler to enforce a specific type. The table below shows each
    type, its syntax, and what it is best suited for.
  </p>

  <div class="table-scroll">
    <table>
      <thead>
        <tr><th>Type</th><th>Example</th><th>Description</th><th>Best for</th></tr>
      </thead>
      <tbody>
        {#each types as t}
          <tr>
            <td><code>{t.type}</code></td>
            <td><code style="color: var(--primary)">{t.example}</code></td>
            <td style="color: var(--muted-foreground)">{t.desc}</td>
            <td style="color: var(--muted-foreground); font-size:0.8125rem">{t.ideal}</td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>

  <h2>Usage Examples</h2>
  <CodeBlock code={usageExample} lang="dixscript" />

  <h2>Numeric Literal Rules</h2>
  <p>
    Decimal, hex, and binary integer literals all follow the same three rules:
    underscore separators, an optional <code>L</code>/<code>l</code> suffix for
    64-bit values, and silent auto-promotion to <code>long</code> on overflow.
    <code>long</code> uses the same <code>&lt;hex&gt;</code> annotation family as
    <code>int</code> for its hex/binary forms — the distinction is the value's
    magnitude and suffix, not a separate annotation.
  </p>
  <CodeBlock code={numericRulesExample} lang="dixscript" />

  <h2>String Literal Styles</h2>
  <p>
    Strings support three interchangeable quote delimiters —
    <code>"..."</code>, <code>'...'</code>, and <code>`...`</code> — all
    producing the exact same string type underneath, so pick whichever
    delimiter needs the least escaping for a given value.
    <code>"</code> and <code>'</code> are escape-processed the normal way
    (<code>\\"</code>, <code>\\'</code>, <code>\\n</code>, etc.).
    <code>`</code> is raw/verbatim — no escape processing at all, so a
    literal <code>"</code> or <code>'</code> inside it needs no escaping,
    and the content may span real newlines directly. Especially useful for
    apostrophe-heavy or multilingual text (contractions, quoted dialogue)
    and any string mixing both quote characters.
  </p>
  <CodeBlock code={stringStylesExample} lang="dixscript" />
  <p>
    One trade-off: <code>$</code>-prefixed interpolated strings only work
    with <code>"</code> or <code>'</code> — a backtick string cannot be
    interpolated, since "no escape processing at all" extends to
    <code>{'{expression}'}</code> too. A raw string containing a literal
    backtick isn't possible either, for the same reason; use <code>"</code>
    or <code>'</code> for that one case.
  </p>

  <h2>Interpolated Strings</h2>
  <p>
    Strings prefixed with <code>$</code> support expression interpolation using
    <code>&#123;expression&#125;</code> syntax. Interpolated strings are fully
    evaluated at compile time.
  </p>
  <CodeBlock code={interpolatedExample} lang="dixscript" />

  <h2>Format Comparison</h2>
  <p>
    How DixScript compares to common configuration and data formats across key features.
    Jsonnet and CUE offer programmable configs with imports and type support.
    HCL (HashiCorp Configuration Language) supports functions and modules in Terraform.
    None support built-in encryption, compression, or binary blob types.
  </p>
  <div class="table-scroll">
    <table>
      <thead>
        <tr>
          <th>Feature</th>
          <th>JSON</th>
          <th>YAML</th>
          <th>TOML</th>
          <th>Jsonnet</th>
          <th>CUE</th>
          <th>HCL</th>
          <th class="th-dix">DixScript</th>
        </tr>
      </thead>
      <tbody>
        {#each cmpRows as row}
          <tr>
            <td style="font-weight:500">{row.feature}</td>
            <td class={row.json    ? 'td-yes' : 'td-no'}>{row.json    ? '✓' : '✗'}</td>
            <td class={row.yaml    ? 'td-yes' : 'td-no'}>{row.yaml    ? '✓' : '✗'}</td>
            <td class={row.toml   ? 'td-yes' : 'td-no'}>{row.toml    ? '✓' : '✗'}</td>
            <td class={row.jsonnet ? 'td-yes' : 'td-no'}>{row.jsonnet ? '✓' : '✗'}</td>
            <td class={row.cue    ? 'td-yes' : 'td-no'}>{row.cue     ? '✓' : '✗'}</td>
            <td class={row.hcl    ? 'td-yes' : 'td-no'}>{row.hcl     ? '✓' : '✗'}</td>
            <td class="td-dix {row.dix ? 'td-yes' : 'td-no'}">{row.dix ? '✓' : '✗'}</td>
          </tr>
        {/each}
      </tbody>
    </table>
  </div>

  <p style="font-size:0.8125rem; color:var(--muted-foreground); margin-top:-0.5rem">
    ✓ = native or first-class support &nbsp;·&nbsp; ✗ = not supported or requires external tooling
  </p>
</div>
